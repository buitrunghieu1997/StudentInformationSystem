CREATE VIEW v_subject AS
  SELECT `s`.`idSubject`     AS `idSubject`,
         `s`.`name`          AS `nameSubject`,
         `s`.`lenght`        AS `length`,
         `s`.`creditSubject` AS `creditSubject`,
         `s`.`creditTuition` AS `creditTuition`,
         `s`.`coefficient`   AS `weight`,
         `g`.`name`          AS `genreName`,
         `d`.`name`          AS `departmentName`
  FROM ((`sis_db`.`subject` `s` JOIN `sis_db`.`genre` `g`) JOIN `sis_db`.`department` `d`)
  WHERE ((`s`.`idGenre` = `g`.`idGenre`) AND (`g`.`idDepartment` = `d`.`idDepartment`));

