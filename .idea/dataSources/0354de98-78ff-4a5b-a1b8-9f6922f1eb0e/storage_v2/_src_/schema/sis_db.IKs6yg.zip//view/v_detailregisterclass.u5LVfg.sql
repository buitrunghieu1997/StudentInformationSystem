CREATE VIEW v_detailregisterclass AS
SELECT `s`.`idStudent`      AS `idStudent`,
       `rc`.`semester`      AS `semester`,
       `sc`.`idSubject`     AS `idSubject`,
       `su`.`name`          AS `name`,
       `sc`.`time`          AS `time`,
       `su`.`creditSubject` AS `creditSubject`,
       `su`.`creditTuition` AS `creditTuition`,
       `drc`.`tuition`      AS `tuition`,
       `drc`.`classCode`    AS `classCode`,
       `drc`.`stt`          AS `stt`,
       `d`.`name`           AS `nameDepartment`
FROM ((((((`sis_db`.`student` `s` JOIN `sis_db`.`registerclass` `rc`) JOIN `sis_db`.`schedule` `sc`) JOIN `sis_db`.`subject` `su`) JOIN `sis_db`.`detailregisterclass` `drc`) JOIN `sis_db`.`department` `d`)
       JOIN `sis_db`.`genre`)
WHERE ((`s`.`idStudent` = `rc`.`idStudent`) AND (`sc`.`idSubject` = `su`.`idSubject`) AND
       (`sc`.`idSchedule` = `drc`.`idSchedule`) AND (`su`.`idGenre` = `sis_db`.`genre`.`idGenre`) AND
       (`sis_db`.`genre`.`idDepartment` = `d`.`idDepartment`));

