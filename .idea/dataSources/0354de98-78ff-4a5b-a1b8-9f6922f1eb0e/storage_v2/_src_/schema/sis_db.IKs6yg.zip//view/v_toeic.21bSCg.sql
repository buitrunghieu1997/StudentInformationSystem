CREATE VIEW v_toeic AS
SELECT `s`.`idStudent`   AS `idStudent`,
       `s`.`fullName`    AS `fullName`,
       `s`.`dateOfBirth` AS `dateOfBirth`,
       `t`.`semester`    AS `semester`,
       `t`.`date`        AS `date`,
       `t`.`point`       AS `point`
FROM (`sis_db`.`student` `s`
       JOIN `sis_db`.`toeic` `t`)
WHERE (`s`.`idStudent` = `t`.`idstudent`);

