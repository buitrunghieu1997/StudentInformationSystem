CREATE VIEW v_schedule AS
  SELECT `s`.`idStudent`   AS `idStudent`,
         `sc`.`time`       AS `time`,
         `sc`.`startWeek`  AS `startWeek`,
         `su`.`lenght`     AS `lenght`,
         `sc`.`room`       AS `room`,
         `drc`.`classCode` AS `classCode`,
         `su`.`idSubject`  AS `idSubject`,
         `su`.`name`       AS `name`,
         `rc`.`semester`   AS `semester`
  FROM ((((`sis_db`.`student` `s` JOIN `sis_db`.`subject` `su`) JOIN `sis_db`.`registerclass` `rc`) JOIN `sis_db`.`detailregisterclass` `drc`) JOIN `sis_db`.`schedule` `sc`)
  WHERE ((`s`.`idStudent` = `rc`.`idStudent`) AND (`rc`.`idRegister` = `drc`.`idRegister`) AND
         (`drc`.`idSchedule` = `sc`.`idSchedule`) AND (`sc`.`idSubject` = `su`.`idSubject`));

