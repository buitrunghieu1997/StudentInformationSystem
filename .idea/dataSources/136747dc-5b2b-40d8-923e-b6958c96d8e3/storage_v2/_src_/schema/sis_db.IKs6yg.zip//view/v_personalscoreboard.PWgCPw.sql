CREATE VIEW v_personalscoreboard AS
  SELECT `s`.`idStudent`       AS `idStudent`,
         `rc`.`semester`       AS `semester`,
         `su`.`idSubject`      AS `idSubject`,
         `su`.`name`           AS `name`,
         `su`.`creditSubject`  AS `creditSubject`,
         `drc`.`classCode`     AS `classCode`,
         `drc`.`midSemPoint`   AS `midSemPoint`,
         `drc`.`finalSemPoint` AS `finalSemPoit`
  FROM ((((`sis_db`.`student` `s` JOIN `sis_db`.`subject` `su`) JOIN `sis_db`.`detailregisterclass` `drc`) JOIN `sis_db`.`registerclass` `rc`) JOIN `sis_db`.`schedule`)
  WHERE ((`s`.`idStudent` = `rc`.`idStudent`) AND (`rc`.`idRegister` = `drc`.`idRegister`) AND
         (`sis_db`.`schedule`.`idSubject` = `su`.`idSubject`) AND
         (`sis_db`.`schedule`.`idSchedule` = `drc`.`idSchedule`));

