CREATE VIEW v_tuitionfee AS
  SELECT `s`.`idStudent`         AS `idStudent`,
         `rc`.`semester`         AS `semester`,
         `rc`.`totalCredit`      AS `totalCredit`,
         `rc`.`tuitionPaid`      AS `tuitionPaid`,
         `rc`.`totalTuition`     AS `totalTuition`,
         `rc`.`tuitionDeadline1` AS `tuitionDeadline1`,
         `rc`.`tuitionDeadline2` AS `tuitionDeadline2`
  FROM (`sis_db`.`student` `s` JOIN `sis_db`.`registerclass` `rc`)
  WHERE (`s`.`idStudent` = `rc`.`idStudent`);

