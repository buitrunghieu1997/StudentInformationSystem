CREATE VIEW v_schedule AS
  SELECT `s`.`idStudent`   AS `idStudent`,
         `sc`.`time`       AS `time`,
         `sc`.`startWeek`  AS `startWeek`,
         `sc`.`room`       AS `room`,
         `drc`.`classCode` AS `classCode`,
         `su`.`idSubject`  AS `idSubject`,
         `su`.`name`       AS `name`
  FROM ((((`sis_db`.`student` `s` JOIN `sis_db`.`schedule` `sc`) JOIN `sis_db`.`detailregisterclass` `drc`) JOIN `sis_db`.`subject` `su`) JOIN `sis_db`.`registerclass` `rc`)
  WHERE ((`sc`.`idSchedule` = `drc`.`idSchedule`) AND (`sc`.`idSubject` = `su`.`idSubject`) AND
         (`rc`.`idRegister` = `drc`.`idRegister`) AND (`s`.`idStudent` = `rc`.`idStudent`));

